'use strict';
// plugins/pappy-pinterest.js — Pinterest image search & download

const axios = require('axios');
const logger = require('../core/logger');

// Scraper API for Pinterest - more reliable than direct API
async function searchPinterest(query, limit = 10) {
    try {
        // Use Pinterest's public search endpoint
        const searchUrl = `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(query)}&rs=typed`;
        
        const response = await axios.get(searchUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'application/json'
            },
            timeout: 15000
        });

        const results = response.data?.resource_response?.data?.results || [];
        return results.slice(0, limit).map(pin => ({
            id: pin.id,
            title: pin.title || pin.grid_title || 'Pinterest Image',
            description: pin.description || '',
            imageUrl: pin.images?.orig?.url || pin.images?.['736x']?.url || pin.images?.['474x']?.url,
            link: `https://pinterest.com/pin/${pin.id}`,
            width: pin.images?.orig?.width || 0,
            height: pin.images?.orig?.height || 0
        })).filter(p => p.imageUrl);
    } catch (error) {
        logger.warn(`[Pinterest] Search failed: ${error.message}`);
        throw new Error('Pinterest search failed. Try different keywords.');
    }
}

async function downloadImage(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: 20000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            },
            maxContentLength: 10 * 1024 * 1024 // 10MB max
        });
        return Buffer.from(response.data);
    } catch (error) {
        throw new Error(`Download failed: ${error.message}`);
    }
}

module.exports = {
    category: 'MEDIA',
    commands: [
        { cmd: '.pinterest', role: 'public' },
        { cmd: '.pin', role: 'public' },
        { cmd: '.pic', role: 'public' }
    ],

    searchPinterest,
    downloadImage,

    execute: async ({ sock, msg, args, text }) => {
        const jid = msg.key.remoteJid;
        const cmd = text.split(' ')[0].toLowerCase();
        const query = args.join(' ').trim();

        if (!query) {
            return sock.sendMessage(jid, { 
                text: `🔍 Usage: ${cmd} <search query>\\n\\nExample: ${cmd} gojo satoru anime` 
            }, { quoted: msg });
        }

        const statusMsg = await sock.sendMessage(jid, {
            text: `🔍 *Searching Pinterest for:* ${query}\\n⏳ Please wait...`
        }, { quoted: msg });

        try {
            const results = await searchPinterest(query, 5);

            if (!results.length) {
                return sock.sendMessage(jid, {
                    text: `❌ No images found for: *${query}*\\n\\nTry different keywords.`
                }, { quoted: msg });
            }

            // Delete status message
            await sock.sendMessage(jid, { delete: statusMsg.key }).catch(() => {});

            // Send images one by one with captions
            for (let i = 0; i < Math.min(results.length, 5); i++) {
                const pin = results[i];
                try {
                    const imageBuffer = await downloadImage(pin.imageUrl);
                    
                    await sock.sendMessage(jid, {
                        image: imageBuffer,
                        caption: `📌 *${pin.title}*\\n${pin.description ? `\\n${pin.description.slice(0, 200)}` : ''}\\n\\n🔗 ${pin.link}`,
                        contextInfo: {
                            externalAdReply: {
                                title: pin.title,
                                body: `Pinterest • ${i + 1}/${Math.min(results.length, 5)}`,
                                mediaType: 1,
                                sourceUrl: pin.link,
                                thumbnailUrl: pin.imageUrl,
                                renderLargerThumbnail: false
                            }
                        }
                    }, { quoted: msg });

                    // Small delay between images
                    if (i < Math.min(results.length, 5) - 1) {
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                } catch (dlError) {
                    logger.warn(`[Pinterest] Image download failed for pin ${pin.id}: ${dlError.message}`);
                }
            }

        } catch (error) {
            logger.error(`[Pinterest] Command failed: ${error.message}`);
            await sock.sendMessage(jid, {
                text: `❌ *Pinterest search failed*\\n\\n${error.message}\\n\\nTry again or use different keywords.`
            }, { quoted: msg });
        }
    }
};
