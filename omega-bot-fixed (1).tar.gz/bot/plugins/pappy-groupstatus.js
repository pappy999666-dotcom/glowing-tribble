// plugins/pappy-groupstatus.js
// Group Status Engine — V4 CORRECT IMPLEMENTATION
//
// ROOT CAUSE (why all previous versions silently delivered but ring never appeared):
//
//   The WhatsApp Group Status ring feature (rolled out 2025-2026) requires a specific
//   combination of ContextInfo fields inside the inner message. Without ALL of them,
//   the WA server accepts the message but does NOT create the group ring.
//
//   Required fields (all must be present):
//
//   1. contextInfo.isGroupStatus = true          (proto field 66, bool)
//      ► THE critical flag. Tells WA server & clients: "this is a group status post".
//        Without this, WA ignores the groupStatusMessageV2 wrapper entirely.
//
//   2. contextInfo.parentGroupJid = "<jid>@g.us" (proto field 35, string)
//      ► Identifies WHICH group's ring to update.
//
//   3. contextInfo.statusSourceType = <int>       (proto field 64, enum)
//      ► TEXT=4, IMAGE=0, VIDEO=1. Tells WA how to render the ring preview.
//
//   4. contextInfo.statusAttributions = [...]     (proto field 65, repeated)
//      ► Author attribution. Must include { groupStatus: { authorJid: botJid } }
//        so WA displays "Posted by [bot]" inside the ring view.
//
//   5. backgroundArgb must be signed int32        (NOT unsigned — drop >>> 0)
//      ► JS bitwise ops return signed int32 naturally. Using >>> 0 makes it uint32
//        which silently corrupts the proto int32 field encoding on the WA server.
//
//   Delivery: send to status@broadcast with statusJidList = group members.
//   The groupStatusMessageV2 (proto field 103, newer) / groupStatusMessage (field 96)
//   wrapper carries the inner message. The stanza also gets group_id attribute.

'use strict';

const fs   = require('fs');
const path = require('path');
const {
    downloadMediaMessage,
    prepareWAMessageMedia,
    generateMessageIDV2,
} = require('@whiskeysockets/baileys');
const logger = require('../core/logger');

// ── Color palette ─────────────────────────────────────────────────────────────

const BG_COLORS = {
    black:  '#000000', blue:   '#1A73E8', red:    '#E53935',
    purple: '#7B1FA2', pink:   '#FFB7C5', white:  '#FFFFFF',
    green:  '#00C853', teal:   '#00897B', orange: '#FF6D00',
    yellow: '#FFD600', navy:   '#0D1B2A', rose:   '#FF4081',
    indigo: '#3949AB', lime:   '#76FF03', cyan:   '#00E5FF',
    gold:   '#FFB300', maroon: '#880E4F', forest: '#1B5E20',
    slate:  '#37474F', violet: '#6200EA', coral:  '#FF6E40',
    mint:   '#A7FFEB', wine:   '#7B1829', sky:    '#29B6F6',
    peach:  '#FFAB91',
};

const COLOR_ROTATION = Object.values(BG_COLORS);
let _colorIdx = 0;
function nextColor() { return COLOR_ROTATION[_colorIdx++ % COLOR_ROTATION.length]; }

const FONTS = { sans: 0, serif: 1, mono: 2, bold: 4 };

// Convert #RRGGBB → signed int32 ARGB (alpha=0xFF fully opaque).
// CRITICAL: No >>> 0. JS bitwise ops return signed int32. That is the correct
// proto int32 encoding. Using >>> 0 produces uint32 which corrupts the field.
function hexToArgb(hex) {
    const h = String(hex || '#000000').replace('#', '').padEnd(6, '0');
    const r = parseInt(h.slice(0, 2), 16) || 0;
    const g = parseInt(h.slice(2, 4), 16) || 0;
    const b = parseInt(h.slice(4, 6), 16) || 0;
    return (0xFF << 24) | (r << 16) | (g << 8) | b; // signed int32
}

// StatusSourceType enum (from WAProto.proto ContextInfo.StatusSourceType):
// IMAGE=0, VIDEO=1, GIF=2, AUDIO=3, TEXT=4, MUSIC_STANDALONE=5
const STATUS_SOURCE_TYPE = { IMAGE: 0, VIDEO: 1, GIF: 2, AUDIO: 3, TEXT: 4 };

// ── Config persistence ────────────────────────────────────────────────────────

const CONFIG_FILE = path.join(__dirname, '../data/gs-config.json');
const DEFAULT_CONFIG = { backgroundColor: '#000000', font: 0, repeat: 1 };
const gsConfigs = new Map();

function loadConfig() {
    try {
        if (!fs.existsSync(CONFIG_FILE)) return;
        const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        for (const [k, v] of Object.entries(saved || {})) gsConfigs.set(k, { ...DEFAULT_CONFIG, ...v });
    } catch {}
}
function saveConfig() {
    try {
        fs.mkdirSync(path.dirname(CONFIG_FILE), { recursive: true });
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(Object.fromEntries(gsConfigs), null, 2));
    } catch {}
}
loadConfig();

function getConfig(scope) {
    const key = String(scope || 'global');
    if (gsConfigs.has(key)) return gsConfigs.get(key);
    const cfg = { ...DEFAULT_CONFIG };
    gsConfigs.set(key, cfg);
    return cfg;
}
function setConfig(scope, patch) {
    const key = String(scope || 'global');
    Object.assign(getConfig(key), patch || {});
    saveConfig();
    return getConfig(key);
}

// ── JID helpers ───────────────────────────────────────────────────────────────

function normalizeJid(jid) {
    return String(jid || '').replace(/:\d+@/, '@').replace(/\s+/g, '');
}

function loadOwnerJids() {
    try {
        const ownerFile = path.join(__dirname, '../data/owner.json');
        if (!fs.existsSync(ownerFile)) return [];
        const data = JSON.parse(fs.readFileSync(ownerFile, 'utf8'));
        return (data.ownerJids || []).map(j => normalizeJid(j));
    } catch { return []; }
}

async function fetchGroupMemberJids(sock, groupJid) {
    if (!groupJid || !groupJid.endsWith('@g.us')) return [];
    try {
        const meta = await sock.groupMetadata(groupJid);
        return (meta?.participants || [])
            .flatMap(p => {
                const jids = [];
                const primary = normalizeJid(p.id);
                if (primary) jids.push(primary);
                if (p.lidJid) {
                    const lid = normalizeJid(p.lidJid);
                    if (lid && lid !== primary) jids.push(lid);
                }
                return jids;
            })
            .filter(j => j && (j.endsWith('@s.whatsapp.net') || j.endsWith('@lid')));
    } catch (e) {
        logger.warn(`[GroupStatus] Could not fetch members: ${e.message}`);
        return [];
    }
}

// ── Media downloader ──────────────────────────────────────────────────────────

async function downloadQuoted(msg, sock) {
    const ctx = msg.message?.extendedTextMessage?.contextInfo;
    if (!ctx?.quotedMessage) return null;
    const quotedMsg = ctx.quotedMessage;
    const isImage   = !!quotedMsg.imageMessage;
    const isVideo   = !!quotedMsg.videoMessage;
    if (!isImage && !isVideo) return null;
    const quotedKey = {
        remoteJid: ctx.remoteJid || msg.key.remoteJid,
        id:        ctx.stanzaId,
        fromMe:    ctx.participant ? normalizeJid(ctx.participant) === normalizeJid(sock.user?.id) : false,
        participant: ctx.participant || undefined,
    };
    try {
        const buffer = await downloadMediaMessage(
            { key: quotedKey, message: quotedMsg }, 'buffer', {},
            { logger: null, reuploadRequest: sock.updateMediaMessage }
        );
        return { buffer, isVideo };
    } catch (e) {
        logger.warn(`[GroupStatus] Quoted media download failed: ${e.message}`);
        return null;
    }
}

// ── GROUP STATUS V4 ───────────────────────────────────────────────────────────

async function postGroupStatusV4(sock, groupJid, content) {
    if (!groupJid || !groupJid.endsWith('@g.us')) {
        throw new Error('Requires a valid group JID (xxx@g.us)');
    }

    const botJid = sock.user?.id ? normalizeJid(sock.user.id) : null;

    // ── Build the CORRECT contextInfo ─────────────────────────────────────────
    // All 4 fields are required for the group ring to appear.
    const buildContextInfo = (sourceType) => ({
        isGroupStatus:      true,                       // field 66 — THE critical flag
        parentGroupJid:     groupJid,                  // field 35 — which group's ring
        statusSourceType:   sourceType,                // field 64 — TEXT=4, IMAGE=0, VIDEO=1
        statusAttributions: [{                          // field 65 — author attribution
            groupStatus: { authorJid: botJid || '' }   // GroupStatus.authorJid
        }],
    });

    // ── Build inner message ───────────────────────────────────────────────────

    let innerMsg;

    if (content.imageBuffer || content.videoBuffer) {
        const isVideo   = !!content.videoBuffer;
        const mediaInput = isVideo ? { video: content.videoBuffer } : { image: content.imageBuffer };
        const sourceType = isVideo ? STATUS_SOURCE_TYPE.VIDEO : STATUS_SOURCE_TYPE.IMAGE;

        logger.info('[GroupStatus] Uploading media...');
        const prepared = await prepareWAMessageMedia(mediaInput, { upload: sock.waUploadToServer });
        const mediaKey = isVideo ? 'videoMessage' : 'imageMessage';

        innerMsg = {
            [mediaKey]: {
                ...prepared[mediaKey],
                caption:     content.caption || '',
                contextInfo: buildContextInfo(sourceType),
            }
        };
    } else {
        // Signed int32 ARGB — correct for proto int32 field
        const argb = hexToArgb(content.backgroundColor || '#000000');
        const font = content.font != null ? content.font : 0;
        const text = String(content.text || '🔱');

        logger.info(`[GroupStatus] Text status: "${text}" argb=${argb} font=${font}`);

        innerMsg = {
            extendedTextMessage: {
                text,
                backgroundArgb: argb,
                font,
                contextInfo:    buildContextInfo(STATUS_SOURCE_TYPE.TEXT),
            }
        };
    }

    // ── Build statusJidList ───────────────────────────────────────────────────

    const members = await fetchGroupMemberJids(sock, groupJid);
    const statusJidList = [...new Set([
        ...(botJid ? [botJid] : []),
        ...members,
    ])].filter(j => j.endsWith('@s.whatsapp.net') || j.endsWith('@lid'));

    logger.info(`[GroupStatus] statusJidList: ${statusJidList.length} JIDs`);

    try { await sock.updateStatusPrivacy('all'); } catch {}

    const results = {};

    // ── Path A: status@broadcast + groupStatusMessageV2 (field 103) ───────────
    // Primary path: uses the 2026 proto field with all correct contextInfo flags.
    // group_id stanza attribute associates the status@broadcast post with the group.
    const runA = async () => {
        try {
            const msgId = generateMessageIDV2(sock.user?.id);
            await sock.relayMessage(
                'status@broadcast',
                { groupStatusMessageV2: { message: innerMsg } },
                {
                    messageId: msgId,
                    statusJidList,
                    additionalAttributes: { group_id: groupJid },
                }
            );
            logger.info(`[GroupStatus] ✅ Path A (broadcast + V2 + group_id) → ${msgId}`);
            results.A = { ok: true, msgId };
        } catch (e) {
            logger.warn(`[GroupStatus] Path A failed: ${e.message}`);
            results.A = { ok: false, error: e.message };
        }
    };

    // ── Path B: group JID relay + groupStatusMessageV2 (field 103) ───────────
    // Alternate: encrypt with group sender key, category=status stanza attribute.
    const runB = async () => {
        try {
            const msgId = generateMessageIDV2(sock.user?.id);
            await sock.relayMessage(
                groupJid,
                { groupStatusMessageV2: { message: innerMsg } },
                {
                    messageId: msgId,
                    additionalAttributes: { category: 'status', group_id: groupJid },
                }
            );
            logger.info(`[GroupStatus] ✅ Path B (group relay + V2 + category=status) → ${msgId}`);
            results.B = { ok: true, msgId };
        } catch (e) {
            logger.warn(`[GroupStatus] Path B failed: ${e.message}`);
            results.B = { ok: false, error: e.message };
        }
    };

    await Promise.allSettled([runA(), runB()]);

    // ── Path C fallback: V1 field 96 via broadcast ────────────────────────────
    if (!results.A?.ok) {
        try {
            const msgId = generateMessageIDV2(sock.user?.id);
            await sock.relayMessage(
                'status@broadcast',
                { groupStatusMessage: { message: innerMsg } },
                {
                    messageId: msgId,
                    statusJidList,
                    additionalAttributes: { group_id: groupJid },
                }
            );
            logger.info(`[GroupStatus] ✅ Path C (broadcast + V1 + group_id) → ${msgId}`);
            results.C = { ok: true, msgId };
        } catch (e) {
            logger.warn(`[GroupStatus] Path C failed: ${e.message}`);
            results.C = { ok: false, error: e.message };
        }
    }

    // ── Path D fallback: V1 field 96 via group relay ──────────────────────────
    if (!results.B?.ok) {
        try {
            const msgId = generateMessageIDV2(sock.user?.id);
            await sock.relayMessage(
                groupJid,
                { groupStatusMessage: { message: innerMsg } },
                {
                    messageId: msgId,
                    additionalAttributes: { category: 'status', group_id: groupJid },
                }
            );
            logger.info(`[GroupStatus] ✅ Path D (group relay + V1 + category=status) → ${msgId}`);
            results.D = { ok: true, msgId };
        } catch (e) {
            logger.warn(`[GroupStatus] Path D failed: ${e.message}`);
            results.D = { ok: false, error: e.message };
        }
    }

    const anyOk = Object.values(results).some(r => r?.ok);
    if (!anyOk) {
        const errs = Object.entries(results).map(([k, v]) => `${k}: ${v?.error}`).join(' | ');
        throw new Error(`All paths failed — ${errs}`);
    }

    return results;
}

// ── PERSONAL STATUS (.gstatus / .ggstatus) ────────────────────────────────────

async function postPersonalStatus(sock, content, opts = {}) {
    const { backgroundColor = '#000000', font = 0, groupJid = null } = opts;

    try { await sock.updateStatusPrivacy('all'); } catch {}

    const botJid     = sock.user?.id ? normalizeJid(sock.user.id) : null;
    const ownerJids  = loadOwnerJids();
    const memberJids = await fetchGroupMemberJids(sock, groupJid);

    const statusJidList = [...new Set([
        ...(botJid ? [botJid] : []),
        ...ownerJids,
        ...memberJids,
    ])].filter(j => j.endsWith('@s.whatsapp.net') || j.endsWith('@lid'));

    if (statusJidList.length === 0) {
        throw new Error('statusJidList empty — socket not connected');
    }

    let payload;
    const sendOpts = { statusJidList };

    if (content.imageBuffer) {
        payload = { image: content.imageBuffer };
        if (content.caption) payload.caption = content.caption;
    } else if (content.videoBuffer) {
        payload = { video: content.videoBuffer };
        if (content.caption) payload.caption = content.caption;
    } else {
        payload = { text: String(content.text || '🔱') };
        sendOpts.backgroundColor = backgroundColor;
        sendOpts.font = font;
    }

    const result = await sock.sendMessage('status@broadcast', payload, sendOpts);
    logger.info(`[GroupStatus] Personal story → ${statusJidList.length} JIDs`);
    return { result, viewerCount: statusJidList.length, memberCount: memberJids.length };
}

// ── Plugin export ─────────────────────────────────────────────────────────────

module.exports = {
    category: 'STATUS',
    commands: [
        { cmd: '.updategstatus', role: 'admin' },
        { cmd: '.updatgstatus',  role: 'admin' },
        { cmd: '.gstatus',       role: 'owner' },
        { cmd: '.ggstatus',      role: 'owner' },
        { cmd: '.pstatus',       role: 'owner' },
        { cmd: '.setstatus',     role: 'owner' },
        { cmd: '.getabout',      role: 'owner' },
    ],

    getGsConfig: getConfig,
    setGsConfig: setConfig,
    BG_COLORS,
    FONTS,

    execute: async ({ sock, msg, args, text, botId }) => {
        const chat = msg.key.remoteJid;
        try {
            const cfg = getConfig(botId);

            const rawCmd  = String(text || '').replace(/^\.\ +/, '.').split(/\s+/)[0].toLowerCase();
            const cmdName = rawCmd === '.updatgstatus' ? '.updategstatus' : rawCmd;
            const restArgs = String(text || '').slice(cmdName.length).trim().split(/\s+/).filter(Boolean);

            const quotedMsg  = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
            const quotedText = quotedMsg?.conversation || quotedMsg?.extendedTextMessage?.text || '';

            const isGroupStatusCmd = cmdName === '.updategstatus';

            if (isGroupStatusCmd && !chat.endsWith('@g.us')) {
                return sock.sendMessage(chat, {
                    text: '❌ Run `.updategstatus` inside a group to post a Group Status ring.'
                });
            }

            // ── .setstatus — update bot's WhatsApp About/bio text ────────────
            // Uses sock.updateProfileStatus(text) which sends an IQ to the server.
            // This is the static text visible under the bot's name in contacts.
            if (cmdName === '.setstatus') {
                const aboutText = restArgs.join(' ') || quotedText;
                if (!aboutText) {
                    return sock.sendMessage(chat, {
                        text: '❌ Usage: `.setstatus <text>`\nExample: `.setstatus Hey there! I am Pappy 🔱`'
                    });
                }
                await sock.sendMessage(chat, { react: { text: '⏳', key: msg.key } }).catch(() => {});
                await sock.updateProfileStatus(aboutText);
                return sock.sendMessage(chat, {
                    text: [
                        '✅ *About text updated*',
                        '',
                        `📝 *New About:* ${aboutText}`,
                        '',
                        '_Visible to contacts under the bot\'s name_',
                    ].join('\n')
                });
            }

            // ── .getabout — read current About/bio text ───────────────────────
            if (cmdName === '.getabout') {
                const botJid = sock.user?.id ? normalizeJid(sock.user.id) : null;
                if (!botJid) return sock.sendMessage(chat, { text: '❌ Bot JID unavailable.' });
                try {
                    const result = await sock.fetchStatus(botJid);
                    const aboutText = result?.status || '_(not set)_';
                    const setAt = result?.setAt ? new Date(result.setAt * 1000).toLocaleString() : 'unknown';
                    return sock.sendMessage(chat, {
                        text: [
                            '📝 *Current About Text*',
                            '',
                            `*Text:* ${aboutText}`,
                            `*Set at:* ${setAt}`,
                        ].join('\n')
                    });
                } catch (e) {
                    return sock.sendMessage(chat, { text: `❌ Could not fetch About: ${e.message}` });
                }
            }

            // ── .pstatus — post a personal story to all contacts ─────────────
            // Simpler version of .gstatus: .pstatus <text> or quote an image/video.
            // Uses backgroundColor from config, supports auto-color rotation.
            if (cmdName === '.pstatus') {
                const storyText = restArgs.join(' ') || quotedText || '🔱';
                const useAutoColor = cfg.backgroundColor === 'auto';
                const storyColor   = useAutoColor ? nextColor() : (cfg.backgroundColor || '#000000');
                const storyFont    = cfg.font != null ? cfg.font : 0;

                const storyMedia = await downloadQuoted(msg, sock);
                const storyContent = {};
                if (storyMedia) {
                    if (storyMedia.isVideo) storyContent.videoBuffer = storyMedia.buffer;
                    else                    storyContent.imageBuffer = storyMedia.buffer;
                    storyContent.caption = storyText;
                } else {
                    storyContent.text = storyText;
                }

                await sock.sendMessage(chat, {
                    text: `📡 *Posting personal story...*`
                }).catch(() => {});

                try {
                    const res = await postPersonalStatus(sock, storyContent, {
                        backgroundColor: storyColor,
                        font: storyFont,
                        groupJid: null,
                    });
                    return sock.sendMessage(chat, {
                        text: [
                            '✅ *Personal Story Posted*',
                            '',
                            `👥 Distributed to *${res.viewerCount} devices*`,
                            '',
                            '_Visible in your WhatsApp Updates tab for 24h_',
                        ].join('\n')
                    });
                } catch (e) {
                    return sock.sendMessage(chat, { text: `❌ Failed: ${e.message}` });
                }
            }

            let textContent = '';
            let repeatCount = 1;

            if (isGroupStatusCmd) {
                textContent = restArgs.join(' ') || quotedText;
            } else {
                repeatCount = Math.max(1, parseInt(restArgs[0]) || 1);
                textContent = restArgs.slice(1).join(' ') || quotedText;
            }

            if (!textContent) textContent = '🔱';

            const useAutoColor = cfg.backgroundColor === 'auto';
            const baseColor    = useAutoColor ? nextColor() : (cfg.backgroundColor || '#000000');
            const font         = cfg.font != null ? cfg.font : 0;

            const media = await downloadQuoted(msg, sock);
            const content = {};
            if (media) {
                if (media.isVideo) content.videoBuffer = media.buffer;
                else               content.imageBuffer = media.buffer;
                content.caption = textContent;
            } else {
                content.text = textContent;
            }

            // ── GROUP STATUS V4 ───────────────────────────────────────────────
            if (isGroupStatusCmd) {
                await sock.sendMessage(chat, {
                    text: '📡 *Posting Group Status V4...*\n_Using isGroupStatus + parentGroupJid + statusAttributions_'
                }).catch(() => {});

                content.backgroundColor = useAutoColor ? nextColor() : baseColor;
                content.font = font;

                try {
                    const results = await postGroupStatusV4(sock, chat, content);

                    const pathLines = Object.entries(results).map(([k, v]) =>
                        `  ${v.ok ? '✅' : '❌'} Path ${k}: ${v.ok ? 'sent' : v.error}`
                    );

                    await sock.sendMessage(chat, {
                        text: [
                            '✅ *Group Status V4 Sent*',
                            '',
                            ...pathLines,
                            '',
                            '━━━━━━━━━━━━━━━━',
                            '📍 *WHERE TO SEE THE RING:*',
                            '1️⃣ Close and reopen WhatsApp',
                            '2️⃣ Open *this group*',
                            '3️⃣ Tap the *group icon* at the top — look for a coloured ring',
                            '4️⃣ Ask another member to check too',
                            '',
                            '_Ring is on the GROUP ICON — not in the Updates tab_',
                        ].join('\n')
                    });
                } catch (err) {
                    logger.error(`[GroupStatus] V4 failed: ${err.message}`);
                    await sock.sendMessage(chat, {
                        text: `❌ Group Status V4 failed: ${err.message}`
                    });
                }
                return;
            }

            // ── PERSONAL STATUS (.gstatus / .ggstatus) ────────────────────────
            await sock.sendMessage(chat, {
                text: `📡 *Posting personal story${repeatCount > 1 ? ` × ${repeatCount}` : ''}...*`
            }).catch(() => {});

            let successCount = 0, failedCount = 0;
            let lastViewerCount = 0, lastMemberCount = 0;

            for (let r = 0; r < repeatCount; r++) {
                const postColor = useAutoColor ? nextColor() : baseColor;
                try {
                    const res = await postPersonalStatus(sock, content, {
                        backgroundColor: postColor,
                        font,
                        groupJid: null,
                    });
                    successCount++;
                    lastViewerCount = res.viewerCount;
                    lastMemberCount = res.memberCount;
                } catch (err) {
                    failedCount++;
                    logger.error(`[GroupStatus] Personal story r${r + 1} failed: ${err.message}`);
                }
                if (repeatCount > 1 && r < repeatCount - 1) {
                    await new Promise(r => setTimeout(r, 3000));
                }
            }

            await sock.sendMessage(chat, {
                text: [
                    `${successCount > 0 ? '✅' : '❌'} *Personal Story Posted*`,
                    `  ✅ Sent: ${successCount}  ❌ Failed: ${failedCount}`,
                    ...(successCount > 0 ? [
                        '',
                        `👥 Distributed to *${lastViewerCount} devices*`,
                        `📊 Members included: ${lastMemberCount}`,
                        '',
                        '_Visible in your WhatsApp Updates tab_',
                    ] : []),
                ].join('\n')
            });

        } catch (err) {
            logger.error(`[GroupStatus] Unhandled: ${err.message}`);
            await sock.sendMessage(chat, { text: `❌ Error: ${err.message}` }).catch(() => {});
        }
    },
};
