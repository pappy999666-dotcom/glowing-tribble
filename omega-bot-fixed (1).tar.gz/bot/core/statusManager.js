// core/statusManager.js
'use strict';

const logger = require('./logger');

// ── Group fetcher ─────────────────────────────────────────────────────────────

async function getGroups(sock) {
    const botId = sock.user?.id?.split(':')[0];
    if (!botId) { logger.error('[StatusManager] Socket has no user ID'); return []; }
    try {
        const groups = await require('./groupCache').getAllGroups(sock, true);
        const jids = Object.keys(groups).filter(j => j.endsWith('@g.us'));
        logger.info(`[${botId}] Groups fetched: ${jids.length}`);
        return jids;
    } catch (err) {
        logger.error(`[${botId}] Failed to fetch groups: ${err.message}`);
        return [];
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _normalizeJid(jid) {
    return String(jid || '').replace(/:\d+@/, '@').replace(/\s+/g, '');
}

function _loadOwnerJids() {
    try {
        const f = require('path').join(__dirname, '../data/owner.json');
        const d = JSON.parse(require('fs').readFileSync(f, 'utf8'));
        return (d.ownerJids || []).map(j => _normalizeJid(j));
    } catch { return []; }
}

async function _fetchGroupMemberJids(sock, groupJid) {
    if (!groupJid || !groupJid.endsWith('@g.us')) return [];
    try {
        const meta = await sock.groupMetadata(groupJid);
        return (meta?.participants || [])
            .map(p => _normalizeJid(p.id))
            .filter(j => j && j.endsWith('@s.whatsapp.net'));
    } catch (e) {
        logger.warn(`[StatusManager] Could not fetch members for ${groupJid}: ${e.message}`);
        return [];
    }
}

// ── Core sender ───────────────────────────────────────────────────────────────
//
//  HOW STATUS VISIBILITY WORKS (Baileys 6.7.23):
//
//  statusJidList → Baileys calls getUSyncDevices(statusJidList) to resolve
//  each JID's Signal devices, then distributes the sender key to them.
//  USync works for ANY registered WhatsApp number — not just saved contacts.
//  Whoever receives the sender key CAN decrypt and see the status.
//
//  Without a JID in statusJidList → no sender key → status is invisible to them.
//
//  updateStatusPrivacy('all') sets the WhatsApp UI filter (who sees the
//  status indicator in the Updates tab). Sender key distribution is separate.
//
//  backgroundColor + font MUST be sendMessage OPTIONS (3rd arg), not payload.

async function postStatus(sock, text, opts = {}) {
    const { backgroundColor = '#00C853', font = 0, extraViewers = [], groupJid = null } = opts;

    try { await sock.updateStatusPrivacy('all'); } catch {}

    const botJid = sock.user?.id ? _normalizeJid(sock.user.id) : null;
    const ownerJids = _loadOwnerJids();

    // extraViewers: backward-compat param (array of JIDs)
    // groupJid: if set, fetch all members and include in statusJidList
    const memberJids = groupJid
        ? await _fetchGroupMemberJids(sock, groupJid)
        : extraViewers.map(j => _normalizeJid(j)).filter(j => j.endsWith('@s.whatsapp.net'));

    const statusJidList = [...new Set([
        ...(botJid ? [botJid] : []),
        ...ownerJids,
        ...memberJids,
    ])].filter(j => j.endsWith('@s.whatsapp.net'));

    logger.info(`[StatusManager] postStatus: ${statusJidList.length} JIDs in statusJidList` +
        ` (${memberJids.length} from group/extraViewers)`);

    return sock.sendMessage(
        'status@broadcast',
        { text: String(text || '🔱') },
        { backgroundColor, font, statusJidList }
    );
}

// Alias for backward compatibility
async function sendGroupStatusToJid(sock, groupJid, text, opts = {}) {
    return postStatus(sock, text, { ...opts, groupJid });
}

// ── Broadcast helper ──────────────────────────────────────────────────────────

async function postTextStatus(sock, text, opts = {}) {
    const {
        repeatCount    = 1,
        repeatDelayMs  = 3000,
        reportJid      = null,
        backgroundColor = '#00C853',
        font           = 0,
        groupJid       = null,
        extraViewers   = [],
    } = opts;

    const botId = sock.user?.id?.split(':')[0] || 'unknown';
    let success = 0, failed = 0;

    for (let i = 0; i < repeatCount; i++) {
        try {
            await postStatus(sock, text, { backgroundColor, font, groupJid, extraViewers });
            success++;
        } catch (err) {
            failed++;
            logger.warn(`[${botId}] Status round ${i + 1} failed: ${err.message}`);
        }
        if (i < repeatCount - 1) await new Promise(r => setTimeout(r, repeatDelayMs));
    }

    logger.info(`[${botId}] postTextStatus done: ${success}/${repeatCount}`);
    if (reportJid) {
        sock.sendMessage(reportJid, {
            text: `✅ *Status Done*\n✅ Sent: ${success}\n❌ Failed: ${failed}`
        }).catch(() => {});
    }
    return { success, failed, total: repeatCount };
}

module.exports = { postTextStatus, getGroups, sendGroupStatusToJid, postStatus };
