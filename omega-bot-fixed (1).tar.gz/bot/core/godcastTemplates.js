'use strict';
// core/godcastTemplates.js
// Hook line | separator | link (alone) | separator | CTA
// Link always on its own line = WhatsApp preview works

const fs   = require('fs');
const path = require('path');
const STORE_FILE = path.join(__dirname, '../data/godcast-group-templates.json');
let _store = {};
function _load() { try { if (fs.existsSync(STORE_FILE)) _store = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8')) || {}; } catch { _store = {}; } }
function _save() { try { fs.mkdirSync(path.dirname(STORE_FILE), { recursive: true }); fs.writeFileSync(STORE_FILE, JSON.stringify(_store, null, 2)); } catch {} }
_load();

// (link) => formatted string
const T = [

(l) => `🌸 you've been chosen 🌸
━━━━━━━━━━━━━━━━━━━━
${l}
━━━━━━━━━━━━━━━━━━━━
tap before it's gone ♡`,

(l) => `💌 your invite is here
⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁
${l}
⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁⌁
don't keep us waiting ♡`,

(l) => `✨ not everyone gets this
─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
${l}
─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
but you do ✨`,

(l) => `🎀 secret drop 🎀
꒰꒰────────────────꒱꒱
${l}
꒰꒰────────────────꒱꒱
join before it closes ♡`,

(l) => `💎 exclusive access only
◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇
${l}
◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇ ◇
you qualify 💎`,

(l) => `🦋 something special
·  ·  ·  ·  ·  ·  ·  ·  ·
${l}
·  ·  ·  ·  ·  ·  ·  ·  ·
flutter in ♡`,

(l) => `🍓 this one's different
୨─────────────────୧
${l}
୨─────────────────୧
taste it 🍓`,

(l) => `☾ after hours drop ☽
· · · · · · · · · · ·
${l}
· · · · · · · · · · ·
real ones only ☾`,

(l) => `🔥 lowkey elite
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
${l}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
tap in 🔥`,

(l) => `⚡ main character energy
━ ━ ━ ━ ━ ━ ━ ━ ━ ━
${l}
━ ━ ━ ━ ━ ━ ━ ━ ━ ━
enter your era ⚡`,

(l) => `🌙 you didn't see this
✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦
${l}
✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦
just join 🌙`,

(l) => `👑 vip invite only
⟡─────────────────⟡
${l}
⟡─────────────────⟡
act fast 👑`,

(l) => `🩷 soft life awaits
♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡
${l}
♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡ ♡
you belong here 🩷`,

(l) => `✿ invitation only ✿
❀ ─ ─ ─ ─ ─ ─ ─ ─ ❀
${l}
❀ ─ ─ ─ ─ ─ ─ ─ ─ ❀
bloom with us ✿`,

(l) => `💫 rare link alert
˚ · . · ˚ · . · ˚ · .
${l}
˚ · . · ˚ · . · ˚ · .
while it lasts 💫`,

(l) => `🎯 one link. one chance.
◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈
${l}
◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈ ◈
don't miss 🎯`,

(l) => `🌺 you're invited 🌺
⊱ ─────────────── ⊰
${l}
⊱ ─────────────── ⊰
step inside ♡`,

(l) => `✧ silent flex ✧
· ─ · ─ · ─ · ─ · ─ ·
${l}
· ─ · ─ · ─ · ─ · ─ ·
real ones know ✧`,

(l) => `🫧 soft but dangerous
꒰ঌ ─────────────── ໒꒱
${l}
꒰ঌ ─────────────── ໒꒱
enter if you dare 🫧`,

(l) => `💌 this is your sign
━━━━━━━━━━━━━━━━━━━━
${l}
━━━━━━━━━━━━━━━━━━━━
don't ignore it 💌`,

(l) => `🌟 new era unlocked
✦ · · · · · · · · · ✦
${l}
✦ · · · · · · · · · ✦
step in 🌟`,

(l) => `🍒 not for everyone
▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸ ▸
${l}
◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂ ◂
but maybe you 🍒`,

(l) => `☁︎ cloud nine vibes ☁︎
~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
${l}
~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
float in ♡`,

(l) => `🔮 it's giving exclusive
⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇
${l}
⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇⌇
join the wave 🔮`,

(l) => `🖤 lowkey drop 🖤
▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬
${l}
▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬ ▬
silent flex 🖤`,

(l) => `🌸 psst… over here 🌸
· · ─ ─ · · ─ ─ · · ─
${l}
· · ─ ─ · · ─ ─ · · ─
don't tell everyone ♡`,

(l) => `⭐ drop of the day
【────────────────】
${l}
【────────────────】
tap & see ⭐`,

(l) => `🎀 kawaii invite 🎀
୨୧ ─────────────── ୨୧
${l}
୨୧ ─────────────── ୨୧
you're one of us now ♡`,

(l) => `💖 it found you
✦ ✧ ✦ ✧ ✦ ✧ ✦ ✧ ✦ ✧
${l}
✦ ✧ ✦ ✧ ✦ ✧ ✦ ✧ ✦ ✧
trust the process 💖`,

// 30 — fallback
(l) => `✨ you're invited ✨
━━━━━━━━━━━━━━━━━━━━
${l}
━━━━━━━━━━━━━━━━━━━━
join us ♡`,

];

function getIndex(groupJid) {
    const k = String(groupJid || '');
    if (_store[k] !== undefined) return _store[k];
    const idx = Math.floor(Math.random() * T.length);
    _store[k] = idx;
    _save();
    return idx;
}

function renderGodcastTemplate({ groupJid, inviteLink, templateIndex } = {}) {
    try {
        const idx = templateIndex !== undefined
            ? Math.max(0, Math.min(Number(templateIndex), T.length - 1))
            : getIndex(groupJid);
        return (T[idx] || T[T.length - 1])(String(inviteLink || ''));
    } catch {
        return T[T.length - 1](String(inviteLink || ''));
    }
}

function resetGroupTemplate(groupJid) { delete _store[String(groupJid || '')]; _save(); }
function assignGroupTemplate(groupJid, idx) { _store[String(groupJid || '')] = Math.max(0, Math.min(Number(idx), T.length - 1)); _save(); }

module.exports = { TEMPLATES: T, TEMPLATE_COUNT: T.length, renderGodcastTemplate, getTemplateIndexForGroup: getIndex, resetGroupTemplate, assignGroupTemplate };
