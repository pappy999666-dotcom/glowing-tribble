# Link Preview Cache System

## Overview
The Link Preview Cache System caches WhatsApp link previews **ONLY when used in commands** - not from every message in every group. This prevents unnecessary caching while ensuring previews are available when needed.

## How It Works

### Automatic Caching
Previews are **automatically cached** when you use these commands WITH a link preview:
- `.godcast` - Caches preview when you send/quote a message with preview
- `.updategstatus` / `.gstatus` / `.ggstatus` - Caches preview when used with preview
- `.tag` - Caches preview when tagging with a link that has preview

### Manual Caching
Use `.cache save` to manually cache a preview:
1. Send a link and wait for WhatsApp to load the preview
2. Reply with `.cache save` or send `.cache save` with the link

### Cache Fallback
When you use a command **without** sending the preview again:
- The system checks if the link is in cache
- If found, uses the cached preview automatically
- If not found, builds a basic preview (backup)

## Commands

### `.cache` - Check current message
Shows if the current or quoted message has a link preview that can be cached.

### `.cache save` - Cache preview
Caches the link preview from the current message or quoted message.

### `.cache list [page]` - View cached previews
Lists all cached link previews with their age and metadata.

### `.cache stats` - Statistics
Shows cache statistics.

### `.cache clear [url]` - Clear cache
Clears specific or all cached previews.

## Benefits

1. **No Preview Needed**: Use commands without sending preview again
2. **Telegram Bridge Support**: Previews work even when sent from Telegram
3. **Persistent**: Cache survives bot restarts (1 year TTL)
4. **Efficient**: Only caches when YOU trigger it
5. **Flexible**: Manual control with `.cache` commands

The "use as is" functionality remains **completely untouched**.
