# 🔱 Omega V5 Test Bot

Premium WhatsApp bot with advanced AI, status management, and multi-node support.

## ✨ Features

### 🤖 AI Integration
- GPT-4 powered conversations
- Image generation and analysis
- Voice note processing with TTS
- Auto-sticker generation
- Context-aware responses

### 📡 Group Status System
- Post status to group icons
- Bulk status broadcasting
- Ghost protocol for reliability
- Queue-based delivery
- Custom colors and fonts

### 🎵 Media Features
- YouTube audio/video downloads
- Song search with polls
- Sticker creation from images
- Image search (Pinterest)
- Lyrics fetching

### 👥 Group Management
- Auto-moderation
- Admin controls
- Group intelligence tracking
- Auto-promote system
- Broadcast messages

### 🔧 Advanced Features
- Multi-session support
- Redis queue system
- MongoDB integration
- Telegram control panel
- Rate limiting
- Auto-reconnect
- Session repair

## 📦 Installation

### Prerequisites
- Node.js 18+ 
- MongoDB
- Redis
- FFmpeg
- yt-dlp

### Setup

1. **Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/omega-v5-test.git
cd omega-v5-test
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment**
```bash
cp .env.example .env
nano .env
```

Required environment variables:
```env
# MongoDB
MONGODB_URI=mongodb://localhost:27017/omega-v5

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# AI (Optional)
OPENAI_API_KEY=your_openai_key
AZURE_OPENAI_KEY=your_azure_key

# Telegram (Optional)
TELEGRAM_BOT_TOKEN=your_bot_token
OWNER_TELEGRAM_ID=your_telegram_id

# Bot Config
OWNER_NUMBER=234XXXXXXXXXX
GLOBAL_PREFIX=.
```

4. **Start the bot**
```bash
# Development
npm start

# Production with PM2
pm2 start ecosystem.config.js
```

## 🎯 Quick Start

### First Run
1. Start the bot with `npm start`
2. Scan QR code or use pairing code
3. Send `.menu` in WhatsApp to see commands

### Group Status Commands
```
.updategstatus [text]    - Post to current group
.ggstatus [text]         - Post to all groups
.fixedgs                 - Reply to message to post as status
```

### AI Commands
```
.pappy on                - Enable AI in group
.pappy off               - Disable AI
pappy [message]          - Talk to AI
```

### Media Commands
```
.play [song]             - Download audio
.song [query]            - Search with interactive poll
.sticker                 - Convert image to sticker
.img [query]             - Search images
```

### Owner Commands
```
.gcast [message]         - Broadcast to all groups
.godcast [message]       - Broadcast with ghost protocol
.broadcast [message]     - Send announcement
```

## 📁 Project Structure

```
omega-v5-test/
├── core/               # Core system modules
│   ├── whatsapp.js    # WhatsApp connection handler
│   ├── ai.js          # AI integration
│   ├── bullEngine.js  # Queue system
│   ├── statusManager.js
│   └── ...
├── plugins/           # Command plugins
│   ├── pappy-groupstatus.js
│   ├── pappy-music.js
│   ├── pappy-admin.js
│   └── ...
├── events/            # Event routers
├── modules/           # Helper modules
├── services/          # External services
├── workers/           # Background workers
├── data/              # Runtime data (gitignored)
└── index.js           # Entry point
```

## 🔧 Configuration

### Group Status Settings
Edit `data/gs-config.json`:
```json
{
  "global": {
    "backgroundColor": "#00C853",
    "font": 3,
    "repeat": 1
  }
}
```

### Command Prefix
Default: `.`
Change with: `.setprefix !`

### Node Mode
- **Public**: Anyone can use commands
- **Private**: Only owner can use
Switch with: `.nodemode private`

## 🐛 Troubleshooting

### Bot not responding
```bash
pm2 logs omega-v5-test
pm2 restart omega-v5-test
```

### Status not posting
1. Check privacy: `.testgs` to verify
2. Verify WhatsApp account supports group status
3. Check logs: `grep "GCStatus" data/logs/pm2-out.log`

### Connection issues
- BAD MAC errors: Bot auto-repairs signal files
- 403 errors: Account may be banned, wait and retry
- Rate limits: Normal, bot auto-retries

### Database issues
```bash
# Check MongoDB
systemctl status mongod

# Check Redis
redis-cli ping
```

## 📚 Documentation

### Status Fix Summary
See: `GROUP_STATUS_FIX_SUMMARY.md`

### Troubleshooting Guide
See: `FINAL_STATUS_TROUBLESHOOTING.md`

### Where to Find Status
See: `WHERE_TO_FIND_STATUS.md`

## 🔐 Security

- Never commit `.env` file
- Keep session data private
- Use strong Redis password
- Limit owner numbers to trusted users
- Regular backups of `data/` folder

## 🚀 Deployment

### VPS Deployment
1. Install Node.js, MongoDB, Redis
2. Clone repository
3. Configure `.env`
4. Run with PM2
5. Setup nginx reverse proxy (optional)

### Docker Deployment
```bash
docker-compose up -d
```

## 📝 Notes

### Group Status Feature
- Requires WhatsApp account with status enabled
- May not work on all accounts/regions
- WhatsApp has been phasing out this feature
- Test with `.fixedgs` command first

### AI Features
- Requires API keys for full functionality
- Image generation uses external APIs
- Rate limits apply

### Rate Limits
- Status posts: ~1 per second
- Commands: Anti-spam built-in
- API calls: Managed by queue system

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

MIT License - See LICENSE file

## 🆘 Support

- Issues: GitHub Issues
- Telegram: @YOUR_SUPPORT_GROUP
- Docs: `/docs` folder

## ⚠️ Disclaimer

This bot is for educational purposes. Use responsibly and comply with WhatsApp Terms of Service. Bulk messaging may result in account bans.

## 🙏 Credits

- Baileys WhatsApp library
- OpenAI for AI capabilities  
- Community contributors

---

**Made with 🔱 by Pappy**

Last Updated: 2026-06-13
