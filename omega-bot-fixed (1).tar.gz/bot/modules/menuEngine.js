'use strict';
// modules/menuEngine.js

const fs   = require('fs');
const path = require('path');

const CATEGORY_ICONS = {
    CORE:     '⚙️',
    ADMIN:    '🛡️',
    STATUS:   '📊',
    MEDIA:    '🎬',
    STICKER:  '🎭',
    MUSIC:    '🎵',
    IMAGE:    '🖼️',
    AI:       '🤖',
    INTEL:    '🔍',
    SYSTEM:   '🖥️',
    GENERAL:  '📌',
    NEXUS:    '🌐',
    WARMUP:   '🔥',
};

// Category display order
const CATEGORY_ORDER = ['CORE','ADMIN','STATUS','MEDIA','MUSIC','IMAGE','STICKER','AI','INTEL','NEXUS','WARMUP','SYSTEM','GENERAL'];

const BORDERS = [
    { top: '╔═════════════════════════╗', mid: '╠═════════════════════════╣', bot: '╚═════════════════════════╝', v: '║' },
    { top: '┌─────────────────────────┐', mid: '├─────────────────────────┤', bot: '└─────────────────────────┘', v: '│' },
    { top: '▛▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▜', mid: '▌─────────────────────────▐', bot: '▙▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▟', v: '▌' },
];

const VIBES = [
    '"clean build. clean output."',
    '"precision over noise."',
    '"built different, runs different."',
    '"every command, encrypted."',
    '"the system never sleeps."',
    '"speed is a feature."',
    '"less talk, more execution."',
    '"engineered to dominate."',
];

function generateMenu(user, opts = {}) {
    const userRole  = String(opts.userRole || 'public').toLowerCase();
    const name      = String(user.name || 'User');
    const mode      = String(user.mode || userRole.toUpperCase());
    const ping      = user.ping != null ? `${user.ping}ms` : '—';
    const level     = user.level != null ? user.level : 0;
    const vibe      = VIBES[Math.floor(Math.random() * VIBES.length)];
    const border    = BORDERS[Math.floor(Math.random() * BORDERS.length)];

    // Collect commands by category
    const pluginsDir = path.join(__dirname, '../plugins');
    const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith('.js'));
    const menuMap = {};
    const seen = new Set();

    for (const file of files) {
        try {
            const plugin = require(path.join(pluginsDir, file));
            if (!plugin.commands) continue;
            const cat = String(plugin.category || 'GENERAL').toUpperCase();
            if (!menuMap[cat]) menuMap[cat] = [];
            for (const command of plugin.commands) {
                const cmdName = String(command.cmd || '').trim();
                if (!cmdName || seen.has(cmdName)) continue;
                if (!hasPermission(userRole, command.role)) continue;
                seen.add(cmdName);
                menuMap[cat].push(cmdName);
            }
        } catch {}
    }

    // Build output
    const lines = [];
    lines.push('');
    lines.push(`${border.top}`);
    lines.push(`${border.v}  ✦  *ΩMEGA PAPPY ULTIMATE*  ✦  ${border.v}`);
    lines.push(`${border.mid}`);
    lines.push(`${border.v}  👤 User   › *${name}*`);
    lines.push(`${border.v}  🎖️ Role   › *${mode}*`);
    lines.push(`${border.v}  ⚡ Ping   › *${ping}*`);
    lines.push(`${border.v}  📈 Cmds   › *${level} used*`);
    lines.push(`${border.bot}`);
    lines.push('');

    // Sort categories
    const cats = [...new Set([...CATEGORY_ORDER, ...Object.keys(menuMap)])].filter(c => menuMap[c]?.length);

    for (const cat of cats) {
        const cmds = menuMap[cat];
        if (!cmds?.length) continue;
        const icon = CATEGORY_ICONS[cat] || '📌';
        lines.push(`┌── ${icon} *${cat}*`);
        // 2 columns
        for (let i = 0; i < cmds.length; i += 2) {
            const a = cmds[i].padEnd(14);
            const b = cmds[i + 1] || '';
            lines.push(`│  ${a}${b}`);
        }
        lines.push(`└${'─'.repeat(25)}`);
        lines.push('');
    }

    lines.push(`> ${vibe}`);
    lines.push('');

    return lines.join('\n');
}

function hasPermission(userRole, requiredRole = 'owner') {
    const roles = { public: 1, admin: 2, owner: 3 };
    return (roles[userRole] || 1) >= (roles[requiredRole] || 3);
}

module.exports = { generateMenu };
