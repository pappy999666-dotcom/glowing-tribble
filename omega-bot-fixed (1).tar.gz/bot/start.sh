#!/bin/bash
# ── Omega Bot Startup Script ─────────────────────────────────
BOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$BOT_DIR"
mkdir -p "$BOT_DIR/data"

# Start Redis if not already running
if ! redis-cli -p 6379 ping > /dev/null 2>&1; then
  echo "[STARTUP] Starting Redis 7..."
  redis-server \
    --daemonize yes \
    --logfile "$BOT_DIR/data/redis.log" \
    --dir "$BOT_DIR/data" \
    --bind 127.0.0.1 \
    --protected-mode no \
    --port 6379
  # Wait for Redis to be ready
  for i in $(seq 1 20); do
    redis-cli -p 6379 ping 2>/dev/null | grep -q PONG && break
    sleep 0.3
  done
fi

REDIS_STATUS=$(redis-cli -p 6379 ping 2>/dev/null || echo "UNAVAILABLE")
echo "[STARTUP] Redis: $REDIS_STATUS"

# Run bot
exec node --expose-gc index.js
