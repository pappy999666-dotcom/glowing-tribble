const fs = require('fs');
const pino = require('pino');
const { getUserSessionDir, isSessionDirValid, cleanCorruptedSession, deleteDir } = require('../utils/storage');
const { Session } = require('../database/models');
const config = require('../config');
const logger = require('../utils/logger');
const { sleep } = require('../utils/helpers');

const active = new Map();

let _lib = null;
async function lib() {
  if (_lib) return _lib;
  _lib = require('@crysnovax/baileys');
  return _lib;
}

async function createWhatsAppSession(telegramId, whatsappNumber, { onCode, onQR, onConnected, onDisconnected } = {}) {
  const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
    delay,
  } = await lib();

  const dir = getUserSessionDir(telegramId, whatsappNumber);
  // isFreshPairing = caller is requesting a brand-new pairing (onCode/onQR present)
  const isFreshPairing = !!(onCode || onQR);
  // isSilentReconnect = neither onCode nor onQR, but also no registered session
  //   (silent reconnect after pairing code was issued, so we keep session dir)

  if (isFreshPairing) {
    // Wipe any stale/partial creds from a previous failed pairing attempt.
    // Baileys will generate fresh noise keys which are saved via creds.update
    // BEFORE the WS closes with 401 — so the subsequent silent reconnect can
    // load them and stay alive for the user to enter the code.
    deleteDir(dir);
    fs.mkdirSync(dir, { recursive: true });
  } else {
    cleanCorruptedSession(dir);
  }

  const { state, saveCreds } = await useMultiFileAuthState(dir);
  let { version } = await fetchLatestBaileysVersion();
  if (!version) version = [2, 3000, 1017531287];

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    printQRInTerminal: false,
    // Browsers.ubuntu('Chrome') is more compatible with pairing code flow
    browser: Browsers ? Browsers.ubuntu('Chrome') : [config.bot.browserName, 'Chrome', '130.0'],
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    markOnlineOnConnect: true,
    keepAliveIntervalMs: 10_000,
    logger: pino({ level: 'silent' }),
    connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000,
    retryRequestDelayMs: 250,
    maxMsgRetryCount: 3,
    fireInitQueries: true,
    emitOwnEvents: false,
    transactionOpts: { maxCommitRetries: 3, delayBetweenTriesMs: 1000 },
    // Prevents BAD MAC errors on reconnect — return cached or empty message
    getMessage: async (key) => {
      if (global.messageCache && key?.id) {
        const cached = global.messageCache.get(key.id);
        if (cached?.message) return cached.message;
      }
      return { conversation: '' };
    },
  });

  const key = `${telegramId}:${whatsappNumber}`;
  active.set(key, sock);
  sock.ev.on('creds.update', saveCreds);

  const isPairing = isFreshPairing && !state.creds.registered;

  // ─── PAIRING CODE: v2 approach ──────────────────────────────────────────────
  // Fire via setTimeout (1.5s) instead of waiting for the qr event.
  // This avoids the race condition where qr fires before requestPairingCode
  // can respond, causing the connection to fail silently.
  if (isPairing && onCode) {
    const cleanNumber = whatsappNumber.replace(/\D/g, '');
    sock._pairingInProgress = true;

    setTimeout(async () => {
      try {
        let code;
        let lastErr;
        for (let attempt = 1; attempt <= 5; attempt++) {
          try {
            if (attempt > 1) await new Promise(r => setTimeout(r, 3000 * attempt));
            code = await sock.requestPairingCode(cleanNumber, 'PAPPYBOT');
            if (code && typeof code === 'string') break;
          } catch (e) {
            lastErr = e;
            const sc = e?.output?.statusCode;
            logger.warn(`Pair attempt ${attempt}/5 for ${whatsappNumber}: ${e.message} (${sc})`);
            if (sc === 401 || sc === 403 || sc === 404) throw e;
            if (attempt === 5) throw e;
          }
        }
        if (!code) throw lastErr || new Error('No pairing code returned');

        sock._pairingCodeSent = true;
        sock._pairingCodeSentAt = Date.now();
        // Pass raw code — pairingHandler.js formats it with dashes
        logger.info(`Pairing code for ${whatsappNumber}: ${code}`);
        await onCode(code);
      } catch (err) {
        if (sock._pairingCodeSent) return;
        logger.error(`Pairing code failed for ${whatsappNumber}: ${err.message}`);
        if (onQR) {
          // fall back to QR if code fails
          sock.ev.once('connection.update', u => { if (u.qr) onQR(u.qr); });
        }
      }
    }, 1500);
  } else if (isPairing && onQR) {
    // QR-only pairing
    let qrSent = false;
    sock.ev.on('connection.update', u => {
      if (u.qr && !qrSent) { qrSent = true; onQR(u.qr); }
    });
  }

  // ─── CONNECTION HANDLING ────────────────────────────────────────────────────
  let connectionResolved = false;

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'open') {
      connectionResolved = true;
      sock._pairingInProgress = false;
      logger.info(`WA connected: ${whatsappNumber}`);
      await Session.findOneAndUpdate(
        { telegramId: String(telegramId), whatsappNumber },
        { isActive: true, lastConnected: new Date(), failCount: 0, lastError: null },
        { upsert: true }
      ).catch(() => {});
      if (onConnected) onConnected(sock);
    }

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const reason = lastDisconnect?.error?.output?.payload?.error;
      const errMsg = String(lastDisconnect?.error?.message || '').toLowerCase();
      logger.info(`WA closed: ${whatsappNumber} (code=${statusCode})`);

      // During active pairing, WhatsApp closes the WebSocket with 401 right
      // after sending the pairing code — this is expected behaviour.
      // We must silently reconnect (WITHOUT requesting a new code) so the
      // socket is alive when the user enters the code on their phone.
      if (sock._pairingCodeSent) {
        const timeSinceCode = Date.now() - (sock._pairingCodeSentAt || 0);
        const keepAliveMs = 3 * 60 * 1000;
        if (timeSinceCode < keepAliveMs) {
          logger.info(`Pairing reconnect for ${whatsappNumber} (code=${statusCode}) — reconnecting silently`);
          active.delete(key);
          // Reconnect without onCode so no new code is issued
          createWhatsAppSession(telegramId, whatsappNumber, {
            onConnected,
            onDisconnected,
          }).catch(e => logger.warn(`Pairing reconnect error: ${e.message}`));
          return;
        }
      }
      // Pre-code 401 during pairing — just ignore, the setTimeout will fire soon
      if (sock._pairingInProgress && !sock._pairingCodeSent) {
        logger.info(`Pre-code close during pairing for ${whatsappNumber} (code=${statusCode}), ignoring`);
        return;
      }

      active.delete(key);
      connectionResolved = true;

      const isLoggedOut = statusCode === DisconnectReason.loggedOut;
      const isBadSession = statusCode === DisconnectReason.badSession
        || errMsg.includes('bad mac')
        || statusCode === 401;
      const isForbidden = statusCode === 403;

      const shouldReconnect = !isLoggedOut && !isBadSession && !isForbidden;

      await Session.findOneAndUpdate(
        { telegramId: String(telegramId), whatsappNumber },
        { isActive: false, lastError: reason || `code_${statusCode}`, $inc: { failCount: 1 } }
      ).catch(() => {});

      if (isBadSession) {
        logger.warn(`Bad session for ${whatsappNumber}, cleaning up`);
        cleanCorruptedSession(dir);
      }

      if (onDisconnected) onDisconnected(shouldReconnect, statusCode);
    }
  });

  return sock;
}

function getSock(tid, num) { return active.get(`${tid}:${num}`); }

async function ensureSock(tid, num) {
  let s = getSock(tid, num);
  if (s) return s;

  s = await reconnect(tid, num);
  if (!s) throw new Error('WhatsApp not connected. Please re-pair.');
  return s;
}

async function reconnect(tid, num) {
  const session = await Session.findOne({ telegramId: String(tid), whatsappNumber: num });
  if (!session) return null;

  const dir = getUserSessionDir(tid, num);
  if (!isSessionDirValid(dir)) return null;

  if (session.failCount >= 5) {
    logger.warn(`Too many failures for ${num}, skipping reconnect`);
    return null;
  }

  return new Promise(res => {
    let done = false;
    const timeout = setTimeout(() => {
      if (!done) { done = true; res(null); }
    }, config.limits.reconnectTimeoutMs);

    createWhatsAppSession(tid, num, {
      onConnected: sock => {
        if (!done) { done = true; clearTimeout(timeout); res(sock); }
      },
      onDisconnected: () => {
        if (!done) { done = true; clearTimeout(timeout); res(null); }
      },
    }).catch(() => {
      if (!done) { done = true; clearTimeout(timeout); res(null); }
    });
  });
}

async function setProfilePicture(tid, num, imagePath) {
  const sock = await ensureSock(tid, num);
  const raw = fs.readFileSync(imagePath);
  await sock.updateProfilePicture(sock.user.id, raw, { hd: true });
}

async function setGroupProfilePicture(sock, groupJid, imagePath) {
  const raw = fs.readFileSync(imagePath);
  await sock.updateProfilePicture(groupJid, raw, { hd: true });
}

async function setDisplayName(tid, num, name) {
  const sock = await ensureSock(tid, num);
  await sock.updateProfileName(name);
}

async function getProfilePicture(tid, num) {
  const sock = await ensureSock(tid, num);
  return sock.profilePictureUrl(sock.user.id, 'image');
}

async function deleteProfilePicture(tid, num) {
  const sock = await ensureSock(tid, num);
  await sock.removeProfilePicture(sock.user.id);
}

async function joinGroupViaInvite(sock, inviteCode) {
  return sock.groupAcceptInvite(inviteCode);
}

async function leaveGroup(sock, groupJid) {
  await sock.groupLeave(groupJid);
}

async function getGroupMetadata(sock, groupJid) {
  return sock.groupMetadata(groupJid);
}

async function isAdminInGroup(sock, groupJid) {
  const meta = await getGroupMetadata(sock, groupJid);
  const botJid = sock.user.id;
  const botId = botJid.split(':')[0] + '@s.whatsapp.net';
  const participant = meta.participants.find(p =>
    p.id === botJid || p.id === botId || p.id.split(':')[0] === botJid.split(':')[0]
  );
  return participant?.admin === 'admin' || participant?.admin === 'superadmin';
}

async function disconnect(tid, num) {
  const s = getSock(tid, num);
  if (s) {
    await s.logout().catch(() => {});
    active.delete(`${tid}:${num}`);
  }
}

function getActiveSessions() {
  return active;
}

module.exports = {
  createWhatsAppSession, setProfilePicture, setGroupProfilePicture,
  setDisplayName, getProfilePicture, deleteProfilePicture,
  joinGroupViaInvite, leaveGroup, getGroupMetadata, isAdminInGroup,
  disconnect, reconnect, getSock, ensureSock, getActiveSessions,
};
