# PAPPYBOT v2.1.0

All-in-one Telegram + WhatsApp bot — profile pictures, wallpapers, AI image gen & media downloads.

## Features
- 📸 WhatsApp profile picture management (set, auto-rotate, group PFP)
- 🌄 Auto-drop daily HD wallpapers to ALL groups/channels (40 categories, 10 imgs, 20-min stagger)
- 🎨 AI Image Generator via OpenRouter (FLUX, DALL-E 3, Stable Diffusion)
- 📥 Universal media downloader (TikTok, Instagram, YouTube, Pinterest, Twitter/X, Facebook, Reddit, Threads)
- 🔍 Pinterest image search
- 💬 Support ticket system
- 👑 Owner panel with broadcast, stats, force-join, manual drop

## Quick Start

### Requirements
- Node.js 18+
- MongoDB (local or Atlas)
- Redis (optional — for auto-PFP scheduler)

### Install
```bash
npm install
cp .env.example .env
# Edit .env with your values
```

### Run
```bash
node src/app.js
```

### Production (with PM2)
```bash
npm install -g pm2
pm2 start src/app.js --name pappybot
pm2 save
pm2 startup
```

## Bot Commands
| Command | Description |
|---------|-------------|
| `/start` | Open main menu |
| `/help` | Help & guide |
| `/imagine <prompt>` | Generate AI image |
| `/download <url>` | Download media |
| `/setname <name>` | Change WA display name |

## Auto-Drop Wallpapers
The bot automatically drops wallpapers to EVERY group and channel it is in:
- 40 categories (anime, gaming, nature, cars, girls, boys, space, dark, lofi, etc.)
- 10 HD images per drop (sent as album)
- 20-minute stagger between categories (~13 hours for a full cycle)
- Repeats every 24 hours
- Includes a "Open Bot DM" button after each drop

To trigger an immediate manual drop: Owner Panel → 🚀 Drop Wallpapers NOW

## Environment Variables
See `.env.example` for full documentation.
