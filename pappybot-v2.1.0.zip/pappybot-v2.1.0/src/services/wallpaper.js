const axios = require('axios');
const path = require('path');
const fs = require('fs');
const config = require('../config');
const logger = require('../utils/logger');
const { Wallpaper, Channel } = require('../database/models');
const { getWallpaperCategoryDir, downloadFile } = require('../utils/storage');
const { sleep } = require('../utils/helpers');

// 40 categories covering every type of wallpaper people use
const CATEGORIES = [
  'anime', 'manga', 'novel_art', 'girls', 'boys',
  'cars', 'nature', 'gaming', 'aesthetic', 'dark',
  'space', 'city', 'abstract', 'sports', 'animals',
  'superheroes', 'flowers', 'quotes', 'fashion', 'food',
  'fantasy', 'sci_fi', 'horror', 'cyberpunk', 'lofi',
  'mountains', 'ocean', 'sunset', 'forest', 'waterfall',
  'architecture', 'vintage', 'minimalist', 'neon',
  'mythology', 'dragons', 'magic', 'warriors',
  'weekend_specials', 'monthly_collections',
];

const CATEGORY_QUERIES = {
  anime:               'anime vertical phone wallpaper 4k portrait ultra hd',
  manga:               'manga art vertical phone wallpaper 4k portrait ultra hd',
  novel_art:           'light novel illustration vertical phone wallpaper 4k ultra hd',
  girls:               'beautiful girl portrait phone wallpaper 4k vertical ultra hd',
  boys:                'handsome man portrait phone wallpaper 4k vertical ultra hd',
  cars:                'sports car vertical phone wallpaper 4k ultra hd',
  nature:              'nature scenery vertical phone wallpaper 4k portrait ultra hd',
  gaming:              'gaming setup vertical phone wallpaper 4k dark ultra hd',
  aesthetic:           'aesthetic pastel vertical phone wallpaper 4k ultra hd',
  dark:                'dark aesthetic moody vertical phone wallpaper 4k ultra hd',
  space:               'galaxy space universe vertical phone wallpaper 4k ultra hd',
  city:                'cityscape night lights vertical phone wallpaper 4k ultra hd',
  abstract:            'abstract art colorful vertical phone wallpaper 4k ultra hd',
  sports:              'sports athlete action vertical phone wallpaper 4k ultra hd',
  animals:             'wildlife animals cute vertical phone wallpaper 4k ultra hd',
  superheroes:         'superhero marvel dc vertical phone wallpaper 4k ultra hd',
  flowers:             'flowers bloom garden vertical phone wallpaper 4k ultra hd',
  quotes:              'motivational quotes text aesthetic vertical phone wallpaper 4k',
  fashion:             'fashion style outfit portrait vertical phone wallpaper 4k ultra hd',
  food:                'food aesthetic delicious vertical phone wallpaper 4k ultra hd',
  fantasy:             'fantasy landscape magical vertical phone wallpaper 4k ultra hd',
  sci_fi:              'science fiction futuristic tech vertical phone wallpaper 4k ultra hd',
  horror:              'dark horror eerie creepy vertical phone wallpaper 4k ultra hd',
  cyberpunk:           'cyberpunk neon city rain vertical phone wallpaper 4k ultra hd',
  lofi:                'lofi cozy aesthetic chill vertical phone wallpaper 4k ultra hd',
  mountains:           'mountain peak snow landscape vertical phone wallpaper 4k ultra hd',
  ocean:               'ocean sea waves beach vertical phone wallpaper 4k ultra hd',
  sunset:              'sunset golden hour sky vertical phone wallpaper 4k ultra hd',
  forest:              'forest trees misty green vertical phone wallpaper 4k ultra hd',
  waterfall:           'waterfall nature water vertical phone wallpaper 4k ultra hd',
  architecture:        'architecture building design vertical phone wallpaper 4k ultra hd',
  vintage:             'vintage retro old school vertical phone wallpaper 4k ultra hd',
  minimalist:          'minimalist clean simple vertical phone wallpaper 4k ultra hd',
  neon:                'neon lights glow colorful vertical phone wallpaper 4k ultra hd',
  mythology:           'mythology gods legends vertical phone wallpaper 4k ultra hd',
  dragons:             'dragon fire fantasy vertical phone wallpaper 4k ultra hd',
  magic:               'magic spell wizard vertical phone wallpaper 4k ultra hd',
  warriors:            'warrior samurai knight armor vertical phone wallpaper 4k ultra hd',
  weekend_specials:    'weekend vibes chill aesthetic vertical phone wallpaper 4k',
  monthly_collections: 'monthly collection best aesthetic vertical phone wallpaper 4k ultra hd',
};

// Track ALL chats bot is in (with AND without admin)
const allChatIds = new Set();
const adminChatIds = new Set();

function addAdminChannel(chatId) {
  if (chatId) { adminChatIds.add(String(chatId)); allChatIds.add(String(chatId)); }
}
function removeAdminChannel(chatId) {
  if (chatId) adminChatIds.delete(String(chatId));
}
function addChat(chatId) {
  if (chatId) allChatIds.add(String(chatId));
}
function removeChat(chatId) {
  if (chatId) { allChatIds.delete(String(chatId)); adminChatIds.delete(String(chatId)); }
}

async function fetchWallpapers(category, count = 10) {
  const query = CATEGORY_QUERIES[category] || `${category.replace(/_/g, ' ')} vertical phone wallpaper 4k ultra hd`;
  const images = [];

  if (config.apis.pexelsKey) {
    try {
      const r = await axios.get('https://api.pexels.com/v1/search', {
        params: { query, per_page: count, page: Math.floor(Math.random() * 8) + 1, orientation: 'portrait', size: 'large' },
        headers: { Authorization: config.apis.pexelsKey },
        timeout: 12000,
      });
      for (const photo of (r.data?.photos || [])) {
        const url = photo.src?.original || photo.src?.large2x || photo.src?.portrait;
        images.push({ url, width: photo.width, height: photo.height, source: 'pexels' });
      }
    } catch (e) { logger.warn(`Pexels (${category}): ${e.message}`); }
  }

  if (images.length < count && config.apis.unsplashKey) {
    try {
      const r = await axios.get('https://api.unsplash.com/search/photos', {
        params: { query, per_page: Math.min(count - images.length, 30), page: Math.floor(Math.random() * 8) + 1, orientation: 'portrait' },
        headers: { Authorization: `Client-ID ${config.apis.unsplashKey}` },
        timeout: 12000,
      });
      for (const photo of (r.data?.results || [])) {
        const url = photo.urls?.raw || photo.urls?.full || photo.urls?.regular;
        images.push({ url, width: photo.width, height: photo.height, source: 'unsplash' });
      }
    } catch (e) { logger.warn(`Unsplash (${category}): ${e.message}`); }
  }

  if (images.length < count) {
    try {
      const { searchImages } = require('./pinterest');
      const page = Math.floor(Math.random() * 5);
      const free = await searchImages(query, page, count - images.length + 8);
      const portrait = free.filter(img => !img.w || !img.h || img.h >= img.w * 0.85);
      for (const img of portrait.slice(0, count - images.length)) {
        images.push({ url: img.url, width: img.w, height: img.h, source: 'free' });
      }
    } catch (e) { logger.warn(`Free (${category}): ${e.message}`); }
  }

  return images.filter(img => img.url).slice(0, count);
}

async function downloadAndStoreWallpapers(category, count = 10) {
  const images = await fetchWallpapers(category, count);
  const dir = getWallpaperCategoryDir(category);
  const stored = [];

  for (const img of images) {
    try {
      const existing = await Wallpaper.findOne({ url: img.url });
      if (existing) { stored.push(existing); continue; }

      const filename = `wp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.jpg`;
      const localPath = path.join(dir, filename);
      try {
        await downloadFile(img.url, localPath);
      } catch {
        stored.push(await Wallpaper.create({ category, url: img.url, source: img.source, width: img.width, height: img.height }));
        continue;
      }
      stored.push(await Wallpaper.create({ category, url: img.url, localPath, source: img.source, width: img.width, height: img.height }));
      await sleep(200);
    } catch (e) { logger.warn(`Download wp: ${e.message}`); }
  }
  return stored;
}

async function getOrFetchWallpapers(category, count = 10) {
  let wallpapers = await Wallpaper.find({ category, postedToTg: false }).sort({ addedAt: 1 }).limit(count);
  if (wallpapers.length < count) {
    const newWps = await downloadAndStoreWallpapers(category, count - wallpapers.length + 4);
    const ids = new Set(wallpapers.map(w => String(w._id)));
    const fresh = newWps.filter(w => !ids.has(String(w._id)) && !w.postedToTg);
    wallpapers = [...wallpapers, ...fresh].slice(0, count);
  }
  return wallpapers;
}

async function postWallpapersToAllTgChannels(bot, category) {
  // Collect destinations: DB channels + ENV channel + ALL chats bot is in
  const dbChannels = await Channel.find({ isActive: true, platform: 'telegram' });
  const chatSet = new Set();
  for (const ch of dbChannels) chatSet.add(ch.chatId || ch.link);
  if (config.channels.telegram) chatSet.add(config.channels.telegram);
  for (const id of allChatIds) chatSet.add(id);

  if (!chatSet.size) {
    logger.info(`Drop ${category}: no chats yet — add bot to groups/channels`);
    return [];
  }

  const wallpapers = await getOrFetchWallpapers(category, 10);
  if (!wallpapers.length) { logger.warn(`Drop ${category}: no wallpapers`); return []; }

  const displayName = category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  const posted = [];

  for (const chatId of chatSet) {
    const batch = wallpapers.slice(0, 10);
    let sentCount = 0;

    // Build media group — prefer URL (no stream issues); fall back to buffer for local-only files
    const mediaItems = [];
    for (const wp of batch) {
      if (wp.url) {
        mediaItems.push({ wp, media: wp.url });
      } else if (wp.localPath && fs.existsSync(wp.localPath)) {
        mediaItems.push({ wp, media: { source: fs.readFileSync(wp.localPath) } });
      }
    }

    if (!mediaItems.length) continue;

    const mediaGroup = mediaItems.map(({ media }, i) => ({
      type: 'photo',
      media,
      ...(i === 0 ? {
        caption:
          `🗂 *${displayName}*\n` +
          `🖼️ ${mediaItems.length} HD wallpapers • ${config.bot.name}`,
        parse_mode: 'Markdown',
      } : {}),
    }));

    // ── Build the "pair + DM" button row shown after every drop ──
    const dmBtn = config.bot.username
      ? { inline_keyboard: [[
          { text: '📱 Pair WhatsApp', url: `https://t.me/${config.bot.username}?start=pair_wa` },
          { text: '💬 More in DM',    url: `https://t.me/${config.bot.username}` },
        ]]}
      : null;

    try {
      await bot.telegram.sendMediaGroup(chatId, mediaGroup);
      sentCount = mediaItems.length;
      mediaItems.forEach(({ wp }) => posted.push({ chatId, wp }));

      // One follow-up message with both buttons — clean, not spammy
      if (dmBtn) {
        await bot.telegram.sendMessage(
          chatId,
          `✨ *Today's ${displayName} wallpapers — saved for you!*\n📲 Tap below to pair WhatsApp or get more:`,
          { parse_mode: 'Markdown', reply_markup: dmBtn }
        ).catch(() => {});
      }
    } catch (err) {
      // Album failed — try URL-only items (skip any that had no URL)
      const urlItems = mediaItems.filter(m => typeof m.media === 'string');
      if (urlItems.length >= 2) {
        try {
          await bot.telegram.sendMediaGroup(chatId, urlItems.map(({ media }, i) => ({
            type: 'photo', media,
            ...(i === 0 ? {
              caption: `🗂 *${displayName}*\n🖼️ ${urlItems.length} HD wallpapers • ${config.bot.name}`,
              parse_mode: 'Markdown',
            } : {}),
          })));
          sentCount = urlItems.length;
          urlItems.forEach(({ wp }) => posted.push({ chatId, wp }));
          if (dmBtn) {
            await bot.telegram.sendMessage(
              chatId,
              `✨ *Today's ${displayName} wallpapers — saved for you!*\n📲 Tap below to pair WhatsApp or get more:`,
              { parse_mode: 'Markdown', reply_markup: dmBtn }
            ).catch(() => {});
          }
        } catch (e2) {
          if (e2.message?.includes('kicked') || e2.message?.includes('not found') ||
              e2.message?.includes('not a member') || e2.message?.includes('deactivated')) {
            removeChat(chatId);
          } else {
            logger.warn(`Drop album ${chatId} (${category}): ${e2.message}`);
          }
        }
      } else if (urlItems.length === 1) {
        // Only 1 image — send as single photo + button
        try {
          await bot.telegram.sendPhoto(chatId, urlItems[0].media, {
            caption: `🗂 *${displayName}* • ${config.bot.name}`,
            parse_mode: 'Markdown',
            ...(dmBtn ? { reply_markup: dmBtn } : {}),
          });
          sentCount = 1;
          posted.push({ chatId, wp: urlItems[0].wp });
        } catch (e3) {
          if (e3.message?.includes('kicked') || e3.message?.includes('not found') ||
              e3.message?.includes('not a member') || e3.message?.includes('deactivated')) {
            removeChat(chatId);
          }
          logger.warn(`Drop single ${chatId} (${category}): ${e3.message}`);
        }
      }
    }

    if (sentCount > 0) logger.info(`Dropped ${sentCount}× ${displayName} album → ${chatId}`);
    await sleep(800);
  }

  const postedIds = new Set(posted.map(p => String(p.wp._id)));
  for (const wp of wallpapers) {
    if (postedIds.has(String(wp._id))) { wp.postedToTg = true; await wp.save().catch(() => {}); }
  }
  return posted;
}

async function postWallpapersToWA(category) {
  const { getOwnerSock, isOwnerConnected } = require('./ownerWhatsapp');
  if (!isOwnerConnected()) return [];

  const waChannels = await Channel.find({ isActive: true, platform: 'whatsapp' });
  if (!waChannels.length) return [];

  const wallpapers = await Wallpaper.find({ category, postedToWa: false }).sort({ addedAt: 1 }).limit(10);
  if (!wallpapers.length) return [];

  const sock = getOwnerSock();
  const displayName = category.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
  const posted = [];

  for (const channel of waChannels) {
    const jid = channel.chatId || channel.link;
    for (const wp of wallpapers) {
      try {
        let imageData;
        if (wp.localPath && fs.existsSync(wp.localPath)) {
          imageData = fs.readFileSync(wp.localPath);
        } else {
          const r = await axios.get(wp.url, { responseType: 'arraybuffer', timeout: 15000 });
          imageData = Buffer.from(r.data);
        }
        await sock.sendMessage(jid, { image: imageData, caption: `📱 *${displayName} Wallpapers*\n\nBy ${config.bot.name}` });
        posted.push(wp);
        await sleep(2500);
      } catch (e) { logger.warn(`WA ${jid} (${category}): ${e.message}`); }
    }
  }

  for (const wp of posted) { wp.postedToWa = true; await wp.save().catch(() => {}); }
  return posted;
}

async function runCategoryDrop(bot, category) {
  logger.info(`Auto-drop: ${category}`);
  try {
    await downloadAndStoreWallpapers(category, 12);
    await postWallpapersToAllTgChannels(bot, category);
    await postWallpapersToWA(category);
  } catch (e) { logger.error(`Drop (${category}): ${e.message}`); }
}

module.exports = {
  CATEGORIES, CATEGORY_QUERIES,
  fetchWallpapers, downloadAndStoreWallpapers,
  getOrFetchWallpapers, postWallpapersToAllTgChannels,
  postWallpapersToWA, runCategoryDrop,
  addAdminChannel, removeAdminChannel,
  addChat, removeChat,
  allChatIds, adminChatIds,
};
