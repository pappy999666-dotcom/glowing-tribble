const { CATEGORIES, runCategoryDrop } = require('../services/wallpaper');
const logger = require('../utils/logger');

// 20 minutes between each category drop
const STAGGER_MS = 20 * 60 * 1000;
// Repeat every 24 hours
const REPEAT_MS  = 24 * 60 * 60 * 1000;

function startWallpaperScheduler(bot) {
  CATEGORIES.forEach((category, index) => {
    const initialDelay = index * STAGGER_MS;

    setTimeout(async () => {
      try {
        await runCategoryDrop(bot, category);
      } catch (e) {
        logger.error(`Wallpaper drop initial (${category}): ${e.message}`);
      }

      setInterval(async () => {
        try {
          await runCategoryDrop(bot, category);
        } catch (e) {
          logger.error(`Wallpaper drop repeat (${category}): ${e.message}`);
        }
      }, REPEAT_MS);
    }, initialDelay);
  });

  const totalMins = Math.floor((CATEGORIES.length * STAGGER_MS) / 60_000);
  logger.info(
    `Wallpaper scheduler: ${CATEGORIES.length} categories, ` +
    `20min stagger (all ${CATEGORIES.length} categories over ~${totalMins} mins, then every 24h)`
  );
}

module.exports = { startWallpaperScheduler };
