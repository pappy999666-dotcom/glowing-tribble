const config = require('../config');

const K = {
  mainMenu(owner = false) {
    const b = [
      [{ text: '🖼️ Pinterest Images',       callback_data: 'pinterest'  }],
      [{ text: '📱 Pair WhatsApp',           callback_data: 'pair_wa'   },
       { text: '👥 Paired Accounts',         callback_data: 'paired'    }],
      [{ text: '🖼️ Change Group PFP',        callback_data: 'group_pfp' }],
      [{ text: '📥 Download Media',          callback_data: 'download'  }],
      [{ text: '🌄 Wallpapers',              callback_data: 'wallpapers'}],
      [{ text: '🎨 AI Image Generator',      callback_data: 'imagegen'  }],
      [{ text: '💬 Support',                 callback_data: 'support'   }],
    ];
    if (owner) b.push([{ text: '👑 Owner Panel', callback_data: 'owner' }]);
    return { inline_keyboard: b };
  },

  accountMenu(num) {
    return { inline_keyboard: [
      [{ text: '🖼️ Change Profile Picture', callback_data: `set_pfp:${num}`   }],
      [{ text: '🔍 Get Current PFP',        callback_data: `get_pfp:${num}`   }],
      [{ text: '🗑️ Delete Profile Picture', callback_data: `del_pfp:${num}`   }],
      [{ text: '✏️ Change WA Display Name', callback_data: `setname:${num}`   }],
      [{ text: '🔄 Auto Change PFP',        callback_data: `auto_pfp:${num}`  }],
      [{ text: '⏹️ Stop Auto Change',       callback_data: `stop_auto:${num}` }],
      [{ text: '🗑️ Purge Session',          callback_data: `purge:${num}`     }],
      [{ text: '‹ Back',                    callback_data: 'paired'           }],
    ]};
  },

  afterPair(num) {
    return { inline_keyboard: [
      [{ text: '🖼️ Set Profile Picture',    callback_data: `set_pfp:${num}` }],
      [{ text: '📌 Make Session Permanent', callback_data: `perm:${num}`    }],
      [{ text: '🗑️ Delete Session',         callback_data: `purge:${num}`   }],
      [{ text: '🏠 Main Menu',              callback_data: 'main_menu'      }],
    ]};
  },

  autoMenu(num) {
    return { inline_keyboard: [
      [{ text: '⏰ Hour Based', callback_data: `auto_hour:${num}` }],
      [{ text: '📅 Day Based',  callback_data: `auto_day:${num}`  }],
      [{ text: '‹ Back',        callback_data: `account:${num}`   }],
    ]};
  },

  groupPfpMenu() {
    return { inline_keyboard: [
      [{ text: '⚡ Immediate Change',        callback_data: 'gpfp_immediate' }],
      [{ text: '📅 Scheduled Daily Change',  callback_data: 'gpfp_scheduled' }],
      [{ text: '📋 My Active Tasks',         callback_data: 'gpfp_tasks'     }],
      [{ text: '‹ Back',                    callback_data: 'main_menu'      }],
    ]};
  },

  downloadMenu() {
    return { inline_keyboard: [
      [{ text: '📌 Pinterest',  callback_data: 'dl_pinterest' },
       { text: '🎵 TikTok',     callback_data: 'dl_tiktok'    }],
      [{ text: '📸 Instagram',  callback_data: 'dl_instagram' },
       { text: '🐦 Twitter/X',  callback_data: 'dl_twitter'   }],
      [{ text: '▶️ YouTube',    callback_data: 'dl_youtube'   },
       { text: '📘 Facebook',   callback_data: 'dl_facebook'  }],
      [{ text: '🧵 Threads',    callback_data: 'dl_threads'   },
       { text: '🤖 Reddit',     callback_data: 'dl_reddit'    }],
      [{ text: '🔗 Auto Detect (paste any URL)', callback_data: 'dl_auto' }],
      [{ text: '‹ Back',        callback_data: 'main_menu'    }],
    ]};
  },

  wallpaperCategories() {
    return { inline_keyboard: [
      [{ text: '🎌 Anime', callback_data: 'wp_anime' }, { text: '📖 Manga', callback_data: 'wp_manga' }],
      [{ text: '📚 Novel Art', callback_data: 'wp_novel_art' }, { text: '👧 Girls', callback_data: 'wp_girls' }],
      [{ text: '👦 Boys', callback_data: 'wp_boys' }, { text: '🚗 Cars', callback_data: 'wp_cars' }],
      [{ text: '🌿 Nature', callback_data: 'wp_nature' }, { text: '🎮 Gaming', callback_data: 'wp_gaming' }],
      [{ text: '✨ Aesthetic', callback_data: 'wp_aesthetic' }, { text: '🌑 Dark', callback_data: 'wp_dark' }],
      [{ text: '🌌 Space', callback_data: 'wp_space' }, { text: '🌆 City', callback_data: 'wp_city' }],
      [{ text: '🎨 Abstract', callback_data: 'wp_abstract' }, { text: '⚽ Sports', callback_data: 'wp_sports' }],
      [{ text: '🦁 Animals', callback_data: 'wp_animals' }, { text: '🦸 Superheroes', callback_data: 'wp_superheroes' }],
      [{ text: '🌸 Flowers', callback_data: 'wp_flowers' }, { text: '💬 Quotes', callback_data: 'wp_quotes' }],
      [{ text: '👗 Fashion', callback_data: 'wp_fashion' }, { text: '🍕 Food', callback_data: 'wp_food' }],
      [{ text: '🧙 Fantasy', callback_data: 'wp_fantasy' }, { text: '🚀 Sci-Fi', callback_data: 'wp_sci_fi' }],
      [{ text: '👻 Horror', callback_data: 'wp_horror' }, { text: '🤖 Cyberpunk', callback_data: 'wp_cyberpunk' }],
      [{ text: '🎵 Lofi', callback_data: 'wp_lofi' }, { text: '⛰ Mountains', callback_data: 'wp_mountains' }],
      [{ text: '🌊 Ocean', callback_data: 'wp_ocean' }, { text: '🌅 Sunset', callback_data: 'wp_sunset' }],
      [{ text: '🌲 Forest', callback_data: 'wp_forest' }, { text: '💧 Waterfall', callback_data: 'wp_waterfall' }],
      [{ text: '🏛 Architecture', callback_data: 'wp_architecture' }, { text: '📷 Vintage', callback_data: 'wp_vintage' }],
      [{ text: '⬜ Minimalist', callback_data: 'wp_minimalist' }, { text: '💡 Neon', callback_data: 'wp_neon' }],
      [{ text: '⚡ Mythology', callback_data: 'wp_mythology' }, { text: '🐉 Dragons', callback_data: 'wp_dragons' }],
      [{ text: '✨ Magic', callback_data: 'wp_magic' }, { text: '⚔ Warriors', callback_data: 'wp_warriors' }],
      [{ text: '🎉 Weekend Specials', callback_data: 'wp_weekend_specials' }],
      [{ text: '📅 Monthly Collections', callback_data: 'wp_monthly_collections' }],
      [{ text: '‹ Back', callback_data: 'main_menu' }],
    ]};
  },

  pinterestBottom(q, page) {
    return { inline_keyboard: [[
      { text: '➕ View More', callback_data: `pi_more:${page + 1}:${q}` },
      { text: '🏠 Main Menu', callback_data: 'main_menu' },
    ]]};
  },

  ownerPanel() {
    return { inline_keyboard: [
      [{ text: '🚀 Drop Wallpapers NOW',         callback_data: 'o_drop_now'  }],
      [{ text: '📣 Broadcast Message',            callback_data: 'o_broadcast' }],
      [{ text: '📊 Statistics',                   callback_data: 'o_stats'     },
       { text: '👥 Users',                        callback_data: 'o_users'     }],
      [{ text: '🔒 Force Join Settings',          callback_data: 'o_fj'        }],
      [{ text: '📢 Channel Management',           callback_data: 'o_channels'  }],
      [{ text: '📱 Owner WA Status',              callback_data: 'o_wa_status' }],
      [{ text: '🔧 Set/Change Owner WA',          callback_data: 'o_wa_set'    }],
      [{ text: '🔗 Pair Owner WA',                callback_data: 'o_wa_pair'   }],
      [{ text: '🔄 Restart Bot',                  callback_data: 'o_restart'   }],
      [{ text: '🏠 Main Menu',                    callback_data: 'main_menu'   }],
    ]};
  },

  dropNowConfirm() {
    return { inline_keyboard: [
      [{ text: '✅ Yes — Drop All 40 Categories Now', callback_data: 'o_drop_now_confirm' }],
      [{ text: '❌ Cancel',                            callback_data: 'owner'              }],
    ]};
  },

  dmButton(botUsername) {
    if (!botUsername) return null;
    return { inline_keyboard: [[
      { text: '💬 Get More · Chat with Bot', url: `https://t.me/${botUsername}` },
    ]]};
  },

  confirm(yes, no = 'main_menu') {
    return { inline_keyboard: [[
      { text: '✅ Confirm', callback_data: yes },
      { text: '❌ Cancel', callback_data: no },
    ]]};
  },

  back(to) { return { inline_keyboard: [[{ text: '‹ Back', callback_data: to }]] }; },
  backMain() { return { inline_keyboard: [[{ text: '🏠 Main Menu', callback_data: 'main_menu' }]] }; },
};

module.exports = K;
